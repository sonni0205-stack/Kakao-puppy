# Fluffy Puppy KakaoTalk Theme — Android

패키지명: `com.kakao.talk.theme.fluffypuppy.moyo`

## 빌드
Android Studio에서 프로젝트를 열고 `app` 모듈을 빌드하거나,
GitHub Actions의 **Build Fluffy Puppy APK** 워크플로를 실행합니다.

생성 파일:
`app/build/outputs/apk/debug/app-debug.apk`

## 설치
1. APK 설치
2. 테마 앱 실행
3. `카카오톡 테마 적용` 선택
4. 또는 카카오톡 → 설정 → 테마에서 `Fluffy Puppy` 선택

이 프로젝트의 강아지 그래픽은 이 대화에서 사용자가 선택한 원본 캐릭터 이미지를 기반으로 구성되어 있습니다.
