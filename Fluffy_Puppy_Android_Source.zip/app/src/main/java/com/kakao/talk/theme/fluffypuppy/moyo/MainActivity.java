package com.kakao.talk.theme.fluffypuppy.moyo;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String KAKAO_PACKAGE = "com.kakao.talk";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        TextView subtitle = findViewById(R.id.subtitle);
        Button action = findViewById(R.id.action);

        if (isKakaoTalkInstalled()) {
            subtitle.setText("카카오톡에서 Fluffy Puppy 테마를 적용해보세요 ♡");
            action.setText("카카오톡 테마 적용");
            action.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("kakaotalk://settings/theme/" + getPackageName()));
                startActivity(intent);
            });
        } else {
            subtitle.setText("카카오톡 설치 후 테마를 적용할 수 있어요.");
            action.setText("카카오톡 설치");
            action.setOnClickListener(v -> {
                startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + KAKAO_PACKAGE)));
            });
        }
    }

    private boolean isKakaoTalkInstalled() {
        try {
            getPackageManager().getPackageInfo(KAKAO_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
