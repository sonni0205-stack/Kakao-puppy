plugins {
    id("com.android.application")
}

android {
    namespace = "com.kakao.talk.theme.fluffypuppy.moyo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kakao.talk.theme.fluffypuppy.moyo"
        minSdk = 28
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0"
    }

    sourceSets {
        getByName("main") {
            res.srcDirs("src/main/res", "src/main/theme", "src/main/theme-adv")
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
        }
    }
}
